import './App.css';
import { useState } from 'react';
import { v4 as uuidV4 } from 'uuid';


const Persons = () => {
  // do not bother yourself with the upper part before the JSX
  const [persons, setPersons] = useState([]);

  const addPerson = () => {
    const clonedPersons = [...persons];
    clonedPersons.push({ id: uuidV4() });
    setPersons(clonedPersons);
  }

  const getRemovePerson = (index) => {
    return (e) => {
      console.log('IMMEDIATELY: ', index, ' - ', e.target.textContent);
      const clonedPersons = [...persons];
      clonedPersons.splice(index, 1);
      setPersons(clonedPersons);

      setTimeout(() => {
        console.log('LATER: ', index, ' - ', e.target.textContent);
      }, 5000);
    };
  }

  return (
    <div style={{padding: 32}}>
      <button onClick={addPerson}>Add</button>
      {
        persons.map(({ id }, index) => (
          <p key={id}>
            {index}:{" "}
            <input type="text" />{" "}
            <button
              onClick={getRemovePerson(index)}
            >
              Purge {index}
            </button>
          </p>
        ))
      }
    </div>
  );
}

const App = () => (
  <div className="App">
    <Persons />
  </div>
);

export default App;
